# PyPI Tool Analog

## Description

PyPI Tool Analog is a prototype Python package management tool designed to demonstrate core package handling functionalities. It supports dependency resolution, parallel downloading of package files from PyPI, and parallel installation of `.whl` (wheel) packages into a specified target environment.

This tool is intended as an educational example and a proof-of-concept for certain package management operations.

## Features

*   **Dependency Resolution:** Identifies and lists all direct and indirect dependencies for a given package.
*   **Parallel Downloads:** Downloads required packages from PyPI concurrently to speed up the acquisition process.
*   **Parallel Installation:** Installs downloaded `.whl` packages into a target directory in parallel.
*   **Command-Line Interface:** Provides a `pypitool` command with sub-commands for different actions (`resolve`, `download`, `install`).

## Requirements

*   Python 3.7+
*   External Dependencies (handled by the package):
    *   `requests>=2.20.0`
    *   `beautifulsoup4>=4.9.0`
*   For installing from source:
    *   `pip`
    *   `build` (install with `pip install build`)

## Installation from Source

To install PyPI Tool Analog from the source code:

1.  **Ensure you have the `build` tool:**
    ```bash
    pip install build
    ```

2.  **Navigate to the project root directory** (where `pyproject.toml` is located).

3.  **Build the package:**
    ```bash
    python -m build
    ```
    This will create a `.whl` file in the `dist/` directory (e.g., `dist/pypi_tool_analog-0.1.0-py3-none-any.whl`).

4.  **Install the built package using pip:**
    ```bash
    pip install dist/pypi_tool_analog-0.1.0-py3-none-any.whl
    ```
    *(Adjust the filename in the command above if the package name or version changes.)*

    Alternatively, you can often build and install in one step from the project root (if you have `setuptools` and `wheel` available, which are part of the `build-system` requires):
    ```bash
    pip install .
    ```

## Usage

The tool is accessed via the `pypitool` command-line interface.

**Basic Structure:**
```bash
pypitool <command> [options] <package_name>
```

**Available Commands:**

*   `pypitool resolve <package_name>`
    *   Resolves and lists all unique dependencies for the specified `<package_name>`.

*   `pypitool download <package_name> [--version <version>] [--output-dir <dir>] [--max-workers <N>]`
    *   Downloads the specified `<package_name>`.
    *   `--version`: Download a specific version. Defaults to the latest suitable if not provided.
    *   `--output-dir`: Directory to save the downloaded file(s) (default: `./downloads/`).
    *   `--max-workers`: Number of parallel workers (currently mainly relevant if the command is extended for multiple packages).

*   `pypitool install <package_name> [--target-dir <dir>] [--max-workers <N>]`
    *   Resolves all dependencies for `<package_name>`, downloads them, and then installs them all into the specified target directory.
    *   `--target-dir`: Directory where packages will be installed (default: `./installed_packages/`). This should typically be a `site-packages` directory within a virtual environment.
    *   `--max-workers`: Number of parallel workers for download and install phases.

**Example for `install` command:**
```bash
pypitool install flask --target-dir ./my_custom_env/site-packages --max-workers 4
```
This command will:
1.  Resolve all dependencies for `flask`.
2.  Download `flask` and all its dependencies into a local `./downloads/` directory.
3.  Install all downloaded `.whl` files into `./my_custom_env/site-packages/`.

**Getting Help:**
To see all available commands:
```bash
pypitool -h
```
For help with a specific command:
```bash
pypitool <command> -h
```
Example: `pypitool install -h`

## Current Limitations & Disclaimer

*   **Prototype Status:** This tool is a prototype and should **not** be considered a replacement for established Python package managers like `pip` or `conda`. It lacks many of their advanced features, error handling, and safety checks.
*   **Wheel (.whl) Files Only:** The installation mechanism currently only supports `.whl` files. It cannot install packages from source distributions (`.tar.gz`, `.zip`).
*   **Basic Dependency Resolution:** Dependency resolution is basic. It identifies required packages but does not perform complex conflict resolution between different package version requirements.
*   **ARM64/Platform Support:** While the tool itself is Python-based and should run on ARM64, successful installation of packages depends on the availability of ARM64-compatible wheels on PyPI. The tool does not yet explicitly prioritize architecture-specific wheels if multiple options are available (though PyPI's simple API often filters by default).

## License

This project is assumed to be under the MIT License (please verify or update if a `LICENSE` file with different terms is added).
The `pyproject.toml` includes a classifier for "License :: OSI Approved :: MIT License".
